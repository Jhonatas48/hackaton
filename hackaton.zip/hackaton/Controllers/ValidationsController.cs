﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace hackaton.Controllers
{
    public class ValidationsController : Controller
    {


        public ActionResult validadeName(String name) {
            if(name == null || name.IsNullOrEmpty())
            {
              
                return BadRequest("Campo Nome obriatório");
            }

            if (name.Length < 3) {
            
                return BadRequest("Campo Nome precisa de no mínimo 3 caracteres");
            }

            return Ok();
        }

        // GET: Validations
        public ActionResult Index()
        {
            return View();
        }

        // GET: Validations/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Validations/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Validations/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Validations/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: Validations/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: Validations/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Validations/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
