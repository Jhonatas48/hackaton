﻿using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.Net;
using System.Security.Policy;
using Microsoft.AspNetCore.Cors;
namespace WebApplication1.Models.Validations
{
    [AttributeUsage(AttributeTargets.Property | AttributeTargets.Field | AttributeTargets.Parameter)]
    public class ValidNameAttribute : ValidationAttribute
    {
        private string _url;
        public ValidNameAttribute(string url)
        {
            _url = url;
        }


        [EnableCors("AllowSpecificOrigin")]
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var name = value as string;

            if (string.IsNullOrEmpty(name))
            {
               return new ValidationResult("O campo Nome é obrigatório.");
            }

            using (var client = new HttpClient())
            {
                var apiUrl = $"{_url}?name={name}";
                try
                {
                    HttpResponseMessage response = client.GetAsync(apiUrl).Result;
                    if (response.IsSuccessStatusCode)
                    {
                        return ValidationResult.Success;
                    }
                    else if (response.StatusCode == HttpStatusCode.BadRequest)
                    {
                        var errorResponse = response.Content.ReadAsStringAsync().Result;
                        return new ValidationResult(errorResponse);
                    }
                    else
                    {
                        return new ValidationResult("Remote validation failed.");
                    }

                }catch(Exception ex)
                {
                    return new ValidationResult("Falha ao validar o campo nome.Serviço Offline");
                }
               
            }
        }
    }
}
