﻿using Microsoft.AspNetCore.Mvc;
using WebApplication1.Models.Validations;

namespace WebApplication1.Models
{
    public class User
    {
        public int id { get; set; }
       
        [ValidName("https://localhost:7294/Validations/validadeName")]
        public string name { get; set; }
    }
}
